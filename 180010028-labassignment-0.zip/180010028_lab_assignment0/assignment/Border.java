package com.assignment;

public class Border {

    int width = 1; // by default the width is set to 1

    public void changeWidth(int tempW){
        width = tempW;
    }


}