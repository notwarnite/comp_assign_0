package com.assignment;

public class Intruder {
    int curr_w = -1;       //initially out of the grid
    int curr_l = -1;       //initially out of the grid

    public void reset(){
        curr_w = -1;
        curr_l = -1;
    }

}

